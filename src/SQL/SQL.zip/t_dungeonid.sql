# MySQL-Front 5.1  (Build 3.57)

/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE */;
/*!40101 SET SQL_MODE='' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES */;
/*!40103 SET SQL_NOTES='ON' */;


# Host: 192.168.15.175    Database: fso
# ------------------------------------------------------
# Server version 5.0.51a-3ubuntu5.4-log

USE `fso`;

#
# Dumping data for table t_dungeonid
#

INSERT INTO `t_dungeonid` VALUES (122);

/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
